export const properties = {
    version: "V3"
};